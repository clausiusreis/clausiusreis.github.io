<style>
    body {background-color: #222; color: white;}
    table {width:20%;}
</style>

<?php

include('connection.php');

//########################################
//# Remover elemento com um link
//########################################

$sql = "SELECT * FROM Teste";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Imprime os dados de cada registro

    echo "<table>";
    echo "<tr><td>ID</td><td>Nome</td><td>Idade</td><td>Excluir</td></tr>";

    while($row = $result->fetch_assoc()) {
        $id    = $row['ID'];
        $nome  = $row['Nome'];
        $idade = $row['Idade'];

        echo "<tr><td>$id</td><td>$nome</td><td>$idade</td><td>
            <a href='aula15_remove.php?ID=$id'>X</a>
            </td></tr>";
    }

    echo "</table>";
} else {
    echo "0 registros retornados";
}

$conn->close();

?>