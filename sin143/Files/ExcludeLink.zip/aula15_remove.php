<style>
    body {background-color: #222; color: white;}
    table {width:20%;}
</style>

<?php

include('connection.php');

//###############################
//# Remover registro
//###############################

$id = $_GET['ID'];

$sql = "DELETE FROM Teste WHERE ID=$id";

if ($conn->query($sql) === TRUE) {
  echo "Record removed successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("Location: aula15.php");
exit();

?>