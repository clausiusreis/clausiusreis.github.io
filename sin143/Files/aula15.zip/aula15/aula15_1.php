<style>body {background-color: #222; color: white;}</style>

<?php

//###############################
//# Conexão com banco de dados  
//###############################

$servername = "localhost";
$username = "clausius";
$password = "mypassword";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
  echo "Connected successfully<br><br>";
  $conn -> select_db("SIN143");
}

?>

