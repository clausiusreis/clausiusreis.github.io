<style>body {background-color: #222; color: white;}</style>

<?php

//###############################
//# Inserir novo registro  
//###############################

include('aula15_1.php');

$sql = "INSERT INTO Teste (Nome, Idade) VALUES ('Robert', 40)";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>