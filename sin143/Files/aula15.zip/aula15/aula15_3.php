<style>body {background-color: #222; color: white;}</style>

<?php

//###############################
//# Atualizar registro
//###############################

include('aula15_1.php');

$sql = "UPDATE Teste SET Idade=51 WHERE Nome='Maia'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>