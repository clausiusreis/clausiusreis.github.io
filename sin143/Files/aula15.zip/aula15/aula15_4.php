<style>body {background-color: #222; color: white;}</style>

<?php

//###############################
//# Remover registro
//###############################

include('aula15_1.php');

$sql = "DELETE FROM Teste WHERE ID=3";

if ($conn->query($sql) === TRUE) {
  echo "Record removed successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>