<style>body {background-color: #222; color: white;}</style>

<?php

//###############################
//# Listar todos os registros
//###############################

include('aula15_1.php');

$sql = "SELECT * FROM Teste";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Imprime os dados de cada registro
  while($row = $result->fetch_assoc()) {
    echo "ID: " . $row["ID"]. "<br> - Nome: " . $row["Nome"]. " - Idade: " . $row["Idade"]. "<br>";
  }
} else {
  echo "0 registros retornados";
}
$conn->close();

?>