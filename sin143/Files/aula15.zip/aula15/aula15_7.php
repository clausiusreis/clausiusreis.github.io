<style>
  body {background-color: #222; color: white;}
  table {width:20%;}
</style>

<?php

//########################################
//# Listar todos os registros com filtro
//########################################

include('aula15_1.php');

$sql = "SELECT * FROM Teste WHERE Idade=25";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Imprime os dados de cada registro

  echo "<table>";
  echo "<tr><td>ID</td><td>Nome</td><td>Idade</td></tr>";

  while($row = $result->fetch_assoc()) {
    $id    = $row['ID'];
    $nome  = $row['Nome'];
    $idade = $row['Idade'];

    echo "<tr><td>$id</td><td>$nome</td><td>$idade</td></tr>";
  }

  echo "</table>";
  
} else {
  echo "0 registros retornados";
}
$conn->close();

?>